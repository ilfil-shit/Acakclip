package com.acakclip.ai

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

data class ClipCandidate(
    val number: Int,
    val start: String,
    val end: String,
    val score: Int,
    val reason: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ACakClipApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ACakClipApp() {
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var analyzing by remember { mutableStateOf(false) }
    var candidates by remember { mutableStateOf<List<ClipCandidate>>(emptyList()) }
    var status by remember { mutableStateOf("Pilih video untuk mulai.") }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        videoUri = uri
        candidates = emptyList()
        status = if (uri != null) "Video siap dianalisis." else "Tidak ada video dipilih."
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("✂️ ACakCLIP") },
                    actions = { Text("V1", modifier = Modifier.padding(end = 16.dp)) }
                )
            }
        ) { pad ->
            LazyColumn(
                modifier = Modifier.padding(pad).fillMaxSize().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text(
                        "AI Clipper untuk Shorts",
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text(
                        "Pilih video podcast, lalu ACakCLIP menyiapkan kandidat momen.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                item {
                    Button(
                        onClick = { picker.launch("video/*") },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.VideoLibrary, null)
                        Spacer(Modifier.width(8.dp))
                        Text("PILIH VIDEO")
                    }
                }

                videoUri?.let { uri ->
                    item { VideoPreview(uri) }
                }

                item {
                    Button(
                        enabled = videoUri != null && !analyzing,
                        onClick = {
                            analyzing = true
                            status = "Menganalisis video…"
                            // V1 UI pipeline placeholder. On-device Whisper integration
                            // is intentionally isolated for the next implementation step.
                            candidates = listOf(
                                ClipCandidate(1, "00:02:14", "00:02:48", 94, "Punchline / reaksi"),
                                ClipCandidate(2, "00:07:31", "00:08:05", 88, "Reaksi kuat"),
                                ClipCandidate(3, "00:15:42", "00:16:20", 86, "Dialog absurd")
                            )
                            analyzing = false
                            status = "Analisis selesai. Pilih clip yang ingin diproses."
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (analyzing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(Modifier.width(8.dp))
                        } else {
                            Icon(Icons.Default.AutoAwesome, null)
                            Spacer(Modifier.width(8.dp))
                        }
                        Text(if (analyzing) "MENGANALISIS…" else "ANALISIS AI")
                    }
                }

                item { Text(status, style = MaterialTheme.typography.bodyMedium) }

                items(candidates) { clip ->
                    ClipCard(clip)
                }
            }
        }
    }
}

@Composable
fun VideoPreview(uri: Uri) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember(uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
        }
    }
    DisposableEffect(player) {
        onDispose { player.release() }
    }
    AndroidView(
        factory = { PlayerView(it).apply { this.player = player } },
        modifier = Modifier.fillMaxWidth().height(260.dp)
    )
}

@Composable
fun ClipCard(clip: ClipCandidate) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("🔥 Clip ${clip.number}", style = MaterialTheme.typography.titleLarge)
                AssistChip(onClick = {}, label = { Text("${clip.score}/100") })
            }
            Spacer(Modifier.height(8.dp))
            Text("${clip.start} → ${clip.end}")
            Text(clip.reason, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = {},
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.ContentCut, null)
                Spacer(Modifier.width(6.dp))
                Text("BUAT CLIP")
            }
        }
    }
}

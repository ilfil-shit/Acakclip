# ACakCLIP V1 — Android Studio

Project native Android dengan Kotlin + Jetpack Compose + Media3.

## Yang sudah ada
- UI native Android
- Pilih video dari HP
- Preview video
- Daftar kandidat clip
- Tampilan skor dan timestamp
- Struktur siap dikembangkan menjadi engine AI on-device

## Build
Buka folder ini dengan Android Studio terbaru yang mendukung Android Gradle Plugin 8.7.x.

Tunggu Gradle sync selesai, lalu:
Build > Build APK(s)

APK debug biasanya berada di:
app/build/outputs/apk/debug/app-debug.apk

## Catatan penting
Pada V1 ini, bagian engine Whisper dan pemotongan video masih dipisahkan dari UI.
Kandidat yang tampil saat tombol ANALISIS AI ditekan adalah data demo untuk memastikan pipeline UI/build berjalan.

Tahap implementasi engine berikutnya:
1. Integrasi Whisper/TFLite/ONNX on-device.
2. Analisis transcript + timestamp.
3. Scoring momen.
4. Media3 Transformer untuk export clip.
5. Crop 9:16.
6. Subtitle otomatis.

Dengan pendekatan ini APK dapat memproses video tanpa server setelah model AI on-device selesai diintegrasikan.
